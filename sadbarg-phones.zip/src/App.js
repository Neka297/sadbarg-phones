import React from "react";
import SadbargPhones from "./SadbargPhones";

function App() {
  return <SadbargPhones />;
}

export default App;
